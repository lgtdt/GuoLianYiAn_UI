# 国联易安前台开发

北京交通大学 翟杰城

## 一、开发环境

系统环境：MacOS

软件环境：Anaconda3 + Python3.10 + PyQt5(对应Python 3.10)

测试环境：Windows, Mac, Linux(Ubuntu 20.04)





## 免责声明

开发者（翟杰城）在开发过程中使用到的所有未知版权的专利元素（如贴图，元素，图标、字体，配色等）仅在开发和内部测试时可用，开发者不对该软件发布后或商用后等情况下软件中所涉及的任何版权不清的专利元素（如贴图，元素，图标、字体，配色等）负责，若软件需要上线商用，请选在原创性作品或明确开源可商用作品，特此声明。下列开发过程中使用到的可能存在不可商用或明确标注不可商用的专利元素：

**字体：**

- 优设标题黑（用于国联易安标题和其下方描述字样），来源：https://www.bilibili.com/read/cv18656246

图标：

- 关闭，来源：https://www.iconfont.cn/user/detail?spm=a313x.7781069.0.d214f71f6&uid=427901&nid=pHshGxdvKGGj

- 最小化，来源：https://www.iconfont.cn/user/detail?spm=a313x.7781069.0.d214f71f6&uid=131445&nid=agM5XO2PULot

- 更多，来源：https://www.iconfont.cn/user/detail?spm=a313x.7781069.0.d214f71f6&uid=799383&nid=4wGLMYecEM6j

- 换肤，来源：https://www.iconfont.cn/user/detail?spm=a313x.7781069.0.d214f71f6&uid=4144077&nid=Qc5t88JG4eP0

- 头像，来源：https://www.iconfont.cn/user/detail?spm=a313x.7781069.0.d214f71f6&uid=511522&nid=5Fc9qfsHJ8rR

- 用户名输入，来源：https://www.iconfont.cn/user/detail?spm=a313x.7781069.0.d214f71f6&uid=5073060&nid=0TjwWAPnJtH0

- 密码输入，来源：https://www.iconfont.cn/user/detail?spm=a313x.7781069.0.d214f71f6&uid=341365&nid=FF537esW99eG

- 对勾，来源：https://www.iconfont.cn/user/detail?spm=a313x.7781069.0.d214f71f6&uid=236930&nid=NgD5XxlTg0xB
